## Crossfilter via dc.js

This visualization is intended as a lead-in for describing the use of [crossfilter](http://square.github.io/crossfilter/) via [dc.js](http://nickqizhu.github.io/dc.js/).

As such it is a very simple example, and is intended to be used in conjunction with a fuller description on [d3noob.org](http://www.d3noob.org/) and in [D3 Tips and Tricks](https://leanpub.com/D3-Tips-and-Tricks).
